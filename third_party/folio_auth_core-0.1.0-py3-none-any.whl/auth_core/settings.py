#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""=================================================
@PROJECT_NAME: folio-auth-core
@File    : settings.py
@Author  : caixiongjiang
@Date    : 2026/09/26
@Function:
    包级配置（环境变量驱动）
    消费方（AKS / skill-server / agent-server）只需设置环境变量，
    无需写代码即可启用验签；也可通过 configure_verifier() 覆盖。

    环境变量（均带 FOLIO_AUTH_ 前缀，避免与其他服务冲突）：
      FOLIO_AUTH_JWKS_URL           folio-auth-server JWKS 端点
      FOLIO_AUTH_ISSUER             本域 JWT issuer（默认 folio-auth）
      FOLIO_AUTH_AUDIENCE           可选，校验 aud claim
      FOLIO_AUTH_LEGACY_SECRET      可选，旧 AKS HS256 密钥（过渡期兼容存量 token）
      FOLIO_AUTH_LEGACY_ISSUER      旧 token issuer（默认 aks-auth）
      FOLIO_AUTH_ADMIN_ROLES        视为管理员的角色集合（默认 admin）
      FOLIO_AUTH_ADMIN_USER_IDS     引导管理员 user_id 白名单（首个管理员授角色前使用）
      FOLIO_AUTH_HEADER_PASSTHROUGH 过渡开关：无 Bearer 时透传 X-User-Id（默认 false，
                                    仅 AKS logto 模式迁移期开启，切换完成后必须关闭）
@Modify History:

@Copyright：Copyright(c) 2024-2026. All Rights Reserved
=================================================="""

import os
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

DEFAULT_JWKS_URL = "http://localhost:8003/api/auth/jwks"
DEFAULT_ISSUER = "folio-auth"
DEFAULT_LEGACY_ISSUER = "aks-auth"


@dataclass(frozen=True)
class AuthCoreSettings:
    """验签配置（不可变；修改请通过 configure_verifier 重建 verifier）"""

    jwks_url: str = DEFAULT_JWKS_URL
    issuer: str = DEFAULT_ISSUER
    audience: Optional[str] = None

    # 旧 AKS HS256 token 过渡校验（仅验证，不签发）
    legacy_secret: Optional[str] = None
    legacy_issuer: str = DEFAULT_LEGACY_ISSUER

    # admin 判定
    admin_roles: Tuple[str, ...] = ("admin",)
    admin_user_ids: Tuple[str, ...] = ()

    # 过渡开关：兼容 AKS logto 模式的 X-User-Id / 明文 user_id 透传
    header_passthrough: bool = False

    # JWKS 缓存
    jwks_cache_ttl_seconds: int = 3600
    jwks_min_refresh_interval_seconds: float = 30.0
    http_timeout_seconds: float = 10.0

    @property
    def admin_roles_list(self) -> List[str]:
        return list(self.admin_roles)


def _split_csv(raw: Optional[str]) -> Tuple[str, ...]:
    return tuple(item.strip() for item in (raw or "").split(",") if item.strip())


def _get_bool(key: str, default: bool = False) -> bool:
    raw = os.getenv(key)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in {"true", "1", "yes", "on", "t", "y"}


def get_auth_core_settings() -> AuthCoreSettings:
    """从环境变量构建配置（不缓存：环境变量在测试中常被临时修改）"""
    return AuthCoreSettings(
        jwks_url=(os.getenv("FOLIO_AUTH_JWKS_URL", "").strip() or DEFAULT_JWKS_URL),
        issuer=(os.getenv("FOLIO_AUTH_ISSUER", "").strip() or DEFAULT_ISSUER),
        audience=(os.getenv("FOLIO_AUTH_AUDIENCE", "").strip() or None),
        legacy_secret=(os.getenv("FOLIO_AUTH_LEGACY_SECRET", "").strip() or None),
        legacy_issuer=(
            os.getenv("FOLIO_AUTH_LEGACY_ISSUER", "").strip() or DEFAULT_LEGACY_ISSUER
        ),
        admin_roles=(_split_csv(os.getenv("FOLIO_AUTH_ADMIN_ROLES")) or ("admin",)),
        admin_user_ids=_split_csv(os.getenv("FOLIO_AUTH_ADMIN_USER_IDS")),
        header_passthrough=_get_bool("FOLIO_AUTH_HEADER_PASSTHROUGH", False),
        jwks_cache_ttl_seconds=int(
            os.getenv("FOLIO_AUTH_JWKS_CACHE_TTL_SECONDS", "").strip() or 3600
        ),
        jwks_min_refresh_interval_seconds=float(
            os.getenv("FOLIO_AUTH_JWKS_MIN_REFRESH_INTERVAL_SECONDS", "").strip() or 30.0
        ),
        http_timeout_seconds=float(
            os.getenv("FOLIO_AUTH_HTTP_TIMEOUT_SECONDS", "").strip() or 10.0
        ),
    )
