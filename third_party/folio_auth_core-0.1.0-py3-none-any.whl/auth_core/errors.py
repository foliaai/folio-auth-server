#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""=================================================
@PROJECT_NAME: folio-auth-core
@File    : errors.py
@Author  : caixiongjiang
@Date    : 2026/09/26
@Function:
    认证异常定义（与 AKS 时期 jwt_manager.AuthTokenError 同名同义，
    消费方迁移时 import 路径替换即可，行为不变）
@Modify History:

@Copyright：Copyright(c) 2024-2026. All Rights Reserved
=================================================="""


class AuthTokenError(Exception):
    """JWT 校验失败（过期 / 非法 / 缺少配置 / JWKS 不可达）"""
