#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""=================================================
@PROJECT_NAME: folio-auth-core
@File    : deps.py
@Author  : caixiongjiang
@Date    : 2026/09/26
@Function:
    FastAPI 认证依赖（三通道 + admin guard）

    与 AKS api/dependencies/auth.py 的同名函数签名保持一致，
    Phase 3 迁移时业务路由零改动：
      - get_current_user_id:            Authorization: Bearer <JWT>
      - get_current_user_id_from_token: ?token=<JWT>（img/react-pdf 等无法带 header 的场景）
      - get_current_user_id_ws:         WebSocket 握手（query token / 子协议）
      - close_unauthorized:             WS 未鉴权统一 close(1008)

    差异说明（有意为之）：
      - 校验只认 folio-auth 签发的 JWT（RS256）+ 可选旧 HS256 过渡
      - X-User-Id 明文透传默认关闭（AKS logto 模式的已知安全漏洞），
        迁移期可通过 FOLIO_AUTH_HEADER_PASSTHROUGH=true 临时恢复，
        前端切换到 /auth-api 登录后必须关闭
@Modify History:

@Copyright：Copyright(c) 2024-2026. All Rights Reserved
=================================================="""

from typing import Optional

from fastapi import Header, HTTPException, Query, WebSocket, status

from auth_core.claims import CurrentUser
from auth_core.errors import AuthTokenError
from auth_core.verifier import get_verifier


def _extract_bearer_token(authorization: Optional[str]) -> Optional[str]:
    """从 Authorization 头中提取 Bearer Token"""
    if not authorization:
        return None

    scheme, _, param = authorization.partition(" ")
    if scheme.strip().lower() != "bearer":
        return None

    return param.strip() or None


async def _verify_token_async(token: str) -> CurrentUser:
    """校验本域 JWT（async 通道）"""
    verifier = get_verifier()
    try:
        return await verifier.verify(token)
    except AuthTokenError as e:
        raise HTTPException(status_code=401, detail=str(e)) from e


def _looks_like_jwt(credential: str) -> bool:
    """粗判凭证形态：三段式 JWT（x.y.z）。透传模式下用于区分旧明文 user_id"""
    return credential.count(".") == 2


# ==================== HTTP：Authorization Header 通道 ====================


async def get_current_user(
    authorization: Optional[str] = Header(None, alias="Authorization"),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
) -> CurrentUser:
    """
    校验请求并返回当前用户（含 role / name / claims）

    - 默认：校验 Authorization: Bearer <JWT>
    - 过渡（FOLIO_AUTH_HEADER_PASSTHROUGH=true）：无 Bearer 时读取
      X-User-Id 明文头（仅限 AKS logto 模式迁移期，等价于旧行为）

    Raises:
        HTTPException: 缺少有效凭证时返回 401
    """
    settings = get_verifier().settings

    token = _extract_bearer_token(authorization)
    if token:
        return await _verify_token_async(token)

    if settings.header_passthrough:
        if x_user_id and x_user_id.strip():
            return CurrentUser(user_id=x_user_id.strip())

    raise HTTPException(status_code=401, detail="缺少登录凭证（Authorization: Bearer）")


async def get_current_user_id(
    authorization: Optional[str] = Header(None, alias="Authorization"),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
) -> str:
    """
    从请求中提取当前用户 ID（与 AKS 同名依赖签名一致，业务路由零改动迁移）

    Returns:
        用户ID字符串

    Raises:
        HTTPException: 缺少有效凭证时返回 401
    """
    user = await get_current_user(authorization, x_user_id)
    return user.user_id


# ==================== HTTP：query token 通道 ====================


async def get_current_user_id_from_token(
    token: str = Query(..., description="登录凭证（query token 通道，与 Authorization 等价）"),
) -> str:
    """
    从 query 参数 ``token`` 提取当前用户 ID。

    适用场景：浏览器原生无法自定义请求头的资源加载（如 react-pdf 的
    ``<Document file={url}>``、``<img src>`` 等），它们只能走普通 GET，
    无法携带 ``Authorization`` header。此时改用 ``?token=<凭证>`` 鉴权，
    与 WebSocket 的 query token 通道保持一致。

    Raises:
        HTTPException: 如果凭证为空或校验失败
    """
    raw_token = (token or "").strip()
    if not raw_token:
        raise HTTPException(status_code=401, detail="缺少有效的用户标识")

    settings = get_verifier().settings
    if settings.header_passthrough and not _looks_like_jwt(raw_token):
        # 过渡期兼容：旧 logto 部署 query 里放的是明文 user_id
        return raw_token

    user = await _verify_token_async(raw_token)
    return user.user_id


# ==================== WebSocket 通道 ====================


async def get_current_user_id_ws(websocket: WebSocket) -> Optional[str]:
    """
    从 WebSocket 握手中提取当前用户 ID

    背景
    ----
    浏览器原生 WebSocket API **不能** 自定义 HTTP header，无法复用 HTTP 版的
    ``Authorization``。生产实践有两种通用做法：

    1. **query token**（首选）: 客户端 ``ws://host/api/chat/ws?token=<凭证>``；
       因为 query 在握手期就到达服务端，可以在 ``accept()`` 之前完成校验。
    2. **Sec-WebSocket-Protocol 子协议**: 把 token 拼到子协议字符串里
       （如 ``aks-chat-v1.<凭证>``），避免暴露到 URL 上（部分 CDN 会记录
       URL）；本函数也兼容这种方式。

    返回 ``None`` 表示鉴权失败，调用方应当 ``close(code=1008)``。本函数
    **不直接抛 HTTPException**，因为在 ``accept()`` 之前 FastAPI 还没有
    建立 ASGI 响应循环，抛异常的效果不可预期。
    """
    # 1) 首选：query token
    token = websocket.query_params.get("token") or websocket.query_params.get(
        "user_id"
    )

    # 2) 备选：Sec-WebSocket-Protocol 形如 "aks-chat-v1.<token>"
    if not (token and token.strip()):
        raw = websocket.headers.get("sec-websocket-protocol") or ""
        for sub in [s.strip() for s in raw.split(",") if s.strip()]:
            if "." in sub:
                _, _, candidate = sub.partition(".")
                if candidate:
                    token = candidate
                    break

    if not (token and token.strip()):
        return None

    credential = token.strip()

    settings = get_verifier().settings
    if settings.header_passthrough and not _looks_like_jwt(credential):
        # 过渡期兼容：旧 logto 部署凭证即 user_id
        return credential

    try:
        user = await get_verifier().verify(credential)
        return user.user_id
    except AuthTokenError:
        return None


async def close_unauthorized(websocket: WebSocket, reason: str = "unauthorized") -> None:
    """统一关闭"未鉴权"的 WS 连接

    code=1008 = Policy Violation（WS 协议规范定义为"鉴权失败"的标准码）
    """
    try:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason=reason)
    except Exception:  # noqa: BLE001
        # 已经断开等场景；忽略
        pass


# ==================== admin guard ====================


async def require_current_user(
    authorization: Optional[str] = Header(None, alias="Authorization"),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
) -> CurrentUser:
    """get_current_user 的显式别名（依赖链书写清晰用）"""
    return await get_current_user(authorization, x_user_id)


async def require_admin(
    authorization: Optional[str] = Header(None, alias="Authorization"),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
) -> CurrentUser:
    """
    管理员守卫：校验凭证 + 角色必须属于 admin 角色

    admin 判定顺序（满足其一即可）：
      1. JWT.role claim ∈ FOLIO_AUTH_ADMIN_ROLES（默认 {"admin"}）
      2. user_id ∈ FOLIO_AUTH_ADMIN_USER_IDS（引导管理员白名单——
         系统第一个管理员还没有角色可授时，用它渡过冷启动）

    Raises:
        HTTPException: 401 未登录 / 403 非管理员
    """
    user = await get_current_user(authorization, x_user_id)

    settings = get_verifier().settings
    if user.role in settings.admin_roles or user.user_id in settings.admin_user_ids:
        return user

    raise HTTPException(status_code=403, detail="需要管理员权限")
