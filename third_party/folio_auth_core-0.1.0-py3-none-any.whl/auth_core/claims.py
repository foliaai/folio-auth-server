#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""=================================================
@PROJECT_NAME: folio-auth-core
@File    : claims.py
@Author  : caixiongjiang
@Date    : 2026/09/26
@Function:
    验签结果载体 CurrentUser
    各后端统一从 user_id 取用户标识、从 role 做权限判断，
    不再各自解析 payload。
@Modify History:

@Copyright：Copyright(c) 2024-2026. All Rights Reserved
=================================================="""

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class CurrentUser:
    """
    验签通过后的当前用户

    Attributes:
        user_id: 用户标识（JWT.sub；OA 模式为工号 EmployeeNo，Logto 模式为 Logto sub）
        name:    展示名（仅用于展示，不参与鉴权）
        role:    角色（folio-auth-server 签发时写入；旧 token 无该 claim 时为 "user"）
        claims:  原始 payload（需要扩展字段时读取，避免频繁破坏 dataclass）
    """

    user_id: str
    name: Optional[str] = None
    role: str = "user"
    claims: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_admin(self) -> bool:
        """是否为 admin 角色（仅判断 role claim；完整的 admin guard 见 deps.require_admin）"""
        return self.role == "admin"
