#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""=================================================
@PROJECT_NAME: folio-auth-core
@File    : verifier.py
@Author  : caixiongjiang
@Date    : 2026/09/26
@Function:
    TokenVerifier：本域 JWT 校验（RS256 为主，过渡期兼容旧 HS256）

    工作方式：
      - RS256：从 folio-auth-server 的 JWKS 端点拉取公钥，本地验签，
               不产生逐请求网络调用；遇到未知 kid 自动刷新一次（支持密钥轮换）
      - HS256：仅当配置了 legacy_secret 时校验旧 AKS token（issuer aks-auth），
               存量 token 过渡期用，Phase 3 收尾后移除
    防护：未知 kid 的强制刷新带最小间隔（_MIN_REFRESH_INTERVAL_SECONDS），
    避免攻击者用随机 kid 放大打挂 JWKS 端点。私钥永远不在本包中出现。
@Modify History:

@Copyright：Copyright(c) 2024-2026. All Rights Reserved
=================================================="""

import asyncio
import inspect
import time
from typing import Any, Callable, Dict, Optional, Union

import httpx
import jwt
from loguru import logger

from auth_core.claims import CurrentUser
from auth_core.errors import AuthTokenError
from auth_core.settings import AuthCoreSettings, get_auth_core_settings

# 允许的算法白名单：显式列出，拒绝 algorithm confusion 攻击
_ALGORITHM_RS256 = "RS256"
_ALGORITHM_HS256 = "HS256"

# 未知 kid 触发的强制刷新默认最小间隔（秒）；可通过
# AuthCoreSettings.jwks_min_refresh_interval_seconds 调整
_DEFAULT_MIN_REFRESH_INTERVAL_SECONDS = 30.0

JWKSFetcher = Callable[[str], Union[Dict[str, Any], "asyncio.Future[Dict[str, Any]]"]]


class TokenVerifier:
    """本域 JWT 校验器（一个进程一个实例即可，内部自带 JWKS 缓存）"""

    def __init__(
        self,
        settings: Optional[AuthCoreSettings] = None,
        *,
        static_jwks: Optional[Dict[str, Any]] = None,
        jwks_fetcher: Optional[JWKSFetcher] = None,
    ) -> None:
        """
        Args:
            settings:      验签配置；缺省时从环境变量读取
            static_jwks:   静态 JWKS 文档（测试或公钥固定的部署使用，
                           提供后不再发起网络请求）
            jwks_fetcher:  自定义 JWKS 拉取函数（测试注入用），签名
                           fetcher(url) -> JWKS dict，同步或 async 均可
        """
        self._settings = settings or get_auth_core_settings()
        self._static_jwks = static_jwks
        self._jwks_fetcher = jwks_fetcher
        # {kid: PyJWK.key}；整体新鲜度用 _cache_fetched_at 判断
        self._key_cache: Dict[str, Any] = {}
        self._cache_fetched_at: float = 0.0
        self._last_refresh_attempt: float = 0.0
        self._refresh_lock = asyncio.Lock()

    @property
    def settings(self) -> AuthCoreSettings:
        """本校验器使用的配置（deps 模块从这里读取，保证与 verifier 一致）"""
        return self._settings

    # ==================== 对外入口 ====================

    async def verify(self, token: str) -> CurrentUser:
        """
        校验本域 JWT 并返回当前用户

        Raises:
            AuthTokenError: token 缺失、过期、签名不合法、issuer 不符或 JWKS 不可达
        """
        raw = (token or "").strip()
        if not raw:
            raise AuthTokenError("缺少有效的登录凭证")

        try:
            header = jwt.get_unverified_header(raw)
        except jwt.PyJWTError as e:
            raise AuthTokenError("无效的登录凭证") from e

        algorithm = header.get("alg")
        if algorithm == _ALGORITHM_RS256:
            payload = await self._decode_rs256(raw, header)
        elif algorithm == _ALGORITHM_HS256:
            payload = self._decode_legacy_hs256(raw)
        else:
            raise AuthTokenError(f"不支持的凭证算法: {algorithm}")

        return self._to_current_user(payload)

    # ==================== RS256 ====================

    async def _decode_rs256(self, token: str, header: Dict[str, Any]) -> Dict[str, Any]:
        kid = header.get("kid")
        key = await self._lookup_key(kid)
        if key is None:
            raise AuthTokenError("登录凭证签名密钥未知，请重新登录")
        return self._decode_with_options(token, key, [_ALGORITHM_RS256])

    async def _lookup_key(self, kid: Optional[str]) -> Optional[Any]:
        """按 kid 查公钥；未命中时刷新 JWKS 再查一次（带最小刷新间隔限频）"""
        cache_key = kid or ""
        key = self._key_cache.get(cache_key)
        if key is not None:
            return key

        await self._refresh_key_cache(force=True)
        return self._key_cache.get(cache_key)

    async def _refresh_key_cache(self, force: bool = False) -> None:
        """拉取 JWKS 并重建缓存（锁保护，避免并发刷新风暴）"""
        async with self._refresh_lock:
            now = time.time()
            if not force and (
                self._cache_fetched_at > 0
                and now - self._cache_fetched_at < self._settings.jwks_cache_ttl_seconds
            ):
                return
            # 限频：就算 kid 全部未知，也不允许短时间反复打 JWKS 端点
            min_interval = getattr(
                self._settings,
                "jwks_min_refresh_interval_seconds",
                _DEFAULT_MIN_REFRESH_INTERVAL_SECONDS,
            )
            if force and self._last_refresh_attempt > 0:
                if now - self._last_refresh_attempt < min_interval:
                    return
            self._last_refresh_attempt = now

            document = await self._load_jwks_document()

            fresh_cache: Dict[str, Any] = {}
            for jwk in document.get("keys", []):
                try:
                    pyjwk = jwt.PyJWK(jwk, algorithm=_ALGORITHM_RS256)
                    fresh_cache[jwk.get("kid") or ""] = pyjwk.key
                except jwt.PyJWTError as e:  # 单个坏 key 不拖垮整份 JWKS
                    logger.warning(f"JWKS 中存在无法解析的公钥（kid={jwk.get('kid')}）: {e}")
            if fresh_cache:
                self._key_cache = fresh_cache
            self._cache_fetched_at = time.time()

    async def _load_jwks_document(self) -> Dict[str, Any]:
        if self._static_jwks is not None:
            return self._static_jwks
        if self._jwks_fetcher is not None:
            result = self._jwks_fetcher(self._settings.jwks_url)
            if inspect.isawaitable(result):
                result = await result
            return result

        try:
            async with httpx.AsyncClient(
                timeout=self._settings.http_timeout_seconds,
                headers={"Accept": "application/json"},
            ) as client:
                response = await client.get(self._settings.jwks_url)
                response.raise_for_status()
                return response.json()
        except (httpx.HTTPError, ValueError) as e:
            logger.error(f"拉取 JWKS 失败: {self._settings.jwks_url}, error={e}")
            raise AuthTokenError("认证服务暂不可用，请稍后重试") from e

    # ==================== 旧 HS256（过渡） ====================

    def _decode_legacy_hs256(self, token: str) -> Dict[str, Any]:
        secret = self._settings.legacy_secret
        if not secret:
            raise AuthTokenError("无效的登录凭证")
        return self._decode_with_options(
            token,
            secret,
            [_ALGORITHM_HS256],
            issuer=self._settings.legacy_issuer,
        )

    # ==================== 公共解析 ====================

    def _decode_with_options(
        self,
        token: str,
        key: Any,
        algorithms: list,
        issuer: Optional[str] = None,
    ) -> Dict[str, Any]:
        decode_kwargs: Dict[str, Any] = {"algorithms": algorithms, "leeway": 30}
        # issuer/audience 与签发方保持一致才参与校验
        effective_issuer = issuer or self._settings.issuer
        if effective_issuer:
            decode_kwargs["issuer"] = effective_issuer
        if self._settings.audience:
            decode_kwargs["audience"] = self._settings.audience

        try:
            return jwt.decode(token, key, **decode_kwargs)
        except jwt.ExpiredSignatureError as e:
            raise AuthTokenError("登录已过期，请重新登录") from e
        except jwt.InvalidTokenError as e:
            logger.warning(f"JWT 校验失败: {e}")
            raise AuthTokenError("无效的登录凭证") from e

    @staticmethod
    def _to_current_user(payload: Dict[str, Any]) -> CurrentUser:
        subject = payload.get("sub")
        if not subject or not str(subject).strip():
            raise AuthTokenError("登录凭证缺少用户标识")

        return CurrentUser(
            user_id=str(subject).strip(),
            name=payload.get("name"),
            role=str(payload.get("role") or "user"),
            claims=payload,
        )


# ==================== 进程级单例 ====================

_default_verifier: Optional[TokenVerifier] = None


def get_verifier() -> TokenVerifier:
    """获取进程级默认校验器（deps 模块使用；首次调用时按环境变量构建）"""
    global _default_verifier
    if _default_verifier is None:
        _default_verifier = TokenVerifier()
    return _default_verifier


def configure_verifier(
    settings: Optional[AuthCoreSettings] = None,
    *,
    static_jwks: Optional[Dict[str, Any]] = None,
    jwks_fetcher: Optional[JWKSFetcher] = None,
) -> TokenVerifier:
    """
    重建并替换默认校验器（应用启动时自定义配置 / 测试注入用）

    Examples:
        configure_verifier(AuthCoreSettings(jwks_url="http://auth:8003/api/auth/jwks"))
    """
    global _default_verifier
    _default_verifier = TokenVerifier(
        settings, static_jwks=static_jwks, jwks_fetcher=jwks_fetcher
    )
    return _default_verifier
