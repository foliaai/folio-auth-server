#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""=================================================
@PROJECT_NAME: folio-auth-core
@File    : __init__.py
@Author  : caixiongjiang
@Date    : 2026/09/26
@Function:
    Folio 统一认证校验包（verify-only）

    职责红线：本包只做"验"，不做"发"——
      - 不持有私钥、不签发任何 token
      - 不包含 OA/Logto 客户端
      - 不访问用户表
    私钥与用户管理只存在于 folio-auth-server。

    模块：
      - claims:    CurrentUser（验签结果）
      - settings:  环境变量驱动的包级配置
      - verifier:  RS256 验签 + JWKS 拉取缓存（支持 kid 轮换、旧 HS256 过渡）
      - deps:      FastAPI 三通道依赖（Header / query token / WebSocket）+ admin guard
@Modify History:

@Copyright：Copyright(c) 2024-2026. All Rights Reserved
=================================================="""

from auth_core.claims import CurrentUser
from auth_core.errors import AuthTokenError
from auth_core.settings import AuthCoreSettings, get_auth_core_settings
from auth_core.verifier import TokenVerifier, configure_verifier, get_verifier

__version__ = "0.1.0"

__all__ = [
    "AuthTokenError",
    "CurrentUser",
    "AuthCoreSettings",
    "get_auth_core_settings",
    "TokenVerifier",
    "get_verifier",
    "configure_verifier",
]
